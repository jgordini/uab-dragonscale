<footer class="footer-bg text-white mt-auto py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>University Relations</h5>
                <p>Administration Building 660<br>
                    1720 2ND Avenue South<br>
                    Birmingham, AL 35294-0106</p>
            </div>
            <div class="col-md-6">
                <h5>Resources</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Web Accessibility</a></li>
                    <li><a href="#" class="text-white">Joomla Training</a></li>
                    <li><a href="#" class="text-white">Website Request Form</a></li>
                    <li><a href="#" class="text-white">Web Support</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS and Popper.js -->
<?php
wp_footer();
?>
</body>

</html>